<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit;
}
require 'config.php';

// Fetch events
$result = mysqli_query($conn, "SELECT * FROM events ORDER BY date_time ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Events</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dashboard {
            display: flex;
        }
        .side-menu {
            width: 220px;
            background-color: #1e1e1e;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }
        .side-menu h2 {
            font-size: 20px;
            margin-bottom: 30px;
        }
        .side-menu a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .side-menu a:hover {
            text-decoration: underline;
        }
        .main-content {
            margin-left: 240px;
            padding: 40px;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="dashboard">
    <div class="side-menu">
        <h2>Admin Panel</h2>
        <a href="manageEvents.php">Manage Events</a>
        <a href="addEvent.php">Add Event</a>
        <a href="viewBookings.php">View Bookings</a>
        <a href="logout.php" style="color: #dc3545;">Logout</a>
    </div>

    <div class="main-content">
        <h2>All Events</h2>
        <table class="events-table">
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Date & Time</th>
                    <th>Location</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= $row['date_time'] ?></td>
                        <td><?= htmlspecialchars($row['location']) ?></td>
                        <td>
                            <a href="viewEvent.php?id=<?= $row['event_id'] ?>">View</a> |
                            <a href="editEvent.php?id=<?= $row['event_id'] ?>">Edit</a> |
                            <a href="deleteEvent.php?id=<?= $row['event_id'] ?>">Delete</a>

                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>


