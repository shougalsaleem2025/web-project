<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit;
}
require 'config.php';

// Make sure ID is passed
if (!isset($_GET['id'])) {
    header("Location: manageEvents.php");
    exit;
}

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM events WHERE event_id  = $id");
$event = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>

<head>
    <title>View Event</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dashboard {
            display: flex;
        }

        .side-menu {
            width: 220px;
            background-color: #1e1e1e;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }

        .side-menu h2 {
            font-size: 20px;
            margin-bottom: 30px;
        }

        .side-menu a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .side-menu a:hover {
            text-decoration: underline;
        }

        .main-content {
            margin-left: 240px;
            padding: 40px;
            width: 100%;
        }

        .event-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 500px;
        }

        .event-card h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .event-card p {
            margin: 8px 0;
            font-size: 16px;
            word-break: break-word;
            text-align: left;
            line-height: 1.6;
        }

        .event-card img {
            display: block;
            max-width: 100%;
            width: 500px;
            height: auto;
            margin: 10px auto;
            border-radius: 6px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }


        .back-button {
            margin-top: 20px;
            display: inline-block;
            padding: 8px 16px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }

        .back-button:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>

    <div class="dashboard">
        <!-- Sidebar -->
        <div class="side-menu">
            <h2>Admin Panel</h2>
            <a href="manageEvents.php">Manage Events</a>
            <a href="addEvent.php">Add Event</a>
            <a href="viewBookings.php">View Bookings</a>
            <a href="logout.php" style="color: #dc3545;">Logout</a>
        </div>

        <!-- Main content -->
        <div class="main-content">
            <div class="event-card">
                <h2>Event Details</h2>
                <p><strong>Name:</strong> <?= htmlspecialchars($event['name']) ?></p>
                <p><strong>Date & Time:</strong> <?= $event['date_time'] ?></p>
                <p><strong>Location:</strong> <?= htmlspecialchars($event['location']) ?></p>
                <p><strong>Ticket Price:</strong> <?= $event['ticket_price'] ?> SAR</p>
                <p><strong>Max Tickets:</strong> <?= $event['max_tickets'] ?></p>

                <?php if (!empty($event['image'])): ?>
                    <p><strong>Image:</strong></p>
                    <img src="<?= htmlspecialchars($event['image']) ?>" alt="Event Image">
                <?php endif; ?>

                <?php if (!empty($event['description'])): ?>
                    <p><strong>Description:</strong><br><?= nl2br(htmlspecialchars($event['description'])) ?></p>
                <?php endif; ?>



                <a href="manageEvents.php" class="back-button">Back</a>
            </div>
        </div>
    </div>

</body>

</html>