<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit;
}

require 'config.php';

// Join bookings with customers and events
$sql = "SELECT 
            b.booking_date, 
            b.num_tickets, 
            b.total_price, 
            c.name AS customer_name, 
            c.email AS customer_email, 
            e.name AS event_name, 
            e.date_time AS event_date
        FROM bookings b
        JOIN customers c ON b.customer_id = 	c.customer_id
        JOIN events e ON b.event_id = 	e.event_id
        ORDER BY b.booking_date DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Bookings</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dashboard {
            display: flex;
        }

        .side-menu {
            width: 220px;
            background-color: #1e1e1e;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }

        .side-menu h2 {
            font-size: 20px;
            margin-bottom: 30px;
        }

        .side-menu a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .side-menu a:hover {
            text-decoration: underline;
        }

        .main-content {
            margin-left: 240px;
            padding: 40px;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- Sidebar navigation -->
    <div class="side-menu">
        <h2>Admin Panel</h2>
        <a href="manageEvents.php">Manage Events</a>
        <a href="addEvent.php">Add Event</a>
        <a href="viewBookings.php">View Bookings</a>
        <a href="logout.php" style="color: #dc3545;">Logout</a>
    </div>

    <!-- Main content -->
    <div class="main-content">
        <h2>All Bookings</h2>

        <table class="events-table">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Email</th>
                    <th>Event</th>
                    <th>Event Date</th>
                    <th>Tickets</th>
                    <th>Total Price</th>
                    <th>Booking Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['customer_name']) ?></td>
                        <td><?= htmlspecialchars($row['customer_email']) ?></td>
                        <td><?= htmlspecialchars($row['event_name']) ?></td>
                        <td><?= $row['event_date'] ?></td>
                        <td><?= $row['num_tickets'] ?></td>
                        <td><?= $row['total_price'] ?> SAR</td>
                        <td><?= $row['booking_date'] ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
