<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit;
}

require 'config.php';

// Make sure event ID exists
if (!isset($_GET['id'])) {
    header("Location: manageEvents.php");
    exit;
}

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM events WHERE event_id = $id");
$event = mysqli_fetch_assoc($result);
$error = "";

// Handle update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $date_time = $_POST["date_time"];
    $location = $_POST["location"];
    $ticket_price = $_POST["ticket_price"];
    $max_tickets = $_POST["max_tickets"];
    $description = $_POST["description"];
    
    // If a new image was uploaded
    $image = $event['image'];
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = "uploads/";
        $imageName = basename($_FILES["image"]["name"]);
        $targetFile = $uploadDir . $imageName;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $image = $targetFile;
        }
    }

    // Update the event
    $stmt = mysqli_prepare($conn, "UPDATE events SET name=?, date_time=?, location=?, ticket_price=?, image=?, max_tickets=?, description=? WHERE event_id=?");
    mysqli_stmt_bind_param($stmt, "sssssisi", $name, $date_time, $location, $ticket_price, $image, $max_tickets, $description, $id);
    mysqli_stmt_execute($stmt);

    header("Location: manageEvents.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Event</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dashboard {
            display: flex;
        }

        .side-menu {
            width: 220px;
            background-color: #1e1e1e;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }

        .side-menu h2 {
            font-size: 20px;
            margin-bottom: 30px;
        }

        .side-menu a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .side-menu a:hover {
            text-decoration: underline;
        }

        .main-content {
            margin-left: 240px;
            padding: 40px;
            width: 100%;
        }

        form input, form textarea, form label {
            display: block;
            width: 300px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            width: auto;
            padding: 8px 16px;
            background-color: #007bff;
            border: none;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .current-img {
            margin-bottom: 10px;
        }

        .current-img img {
            max-width: 300px;
            height: auto;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- Sidebar -->
    <div class="side-menu">
        <h2>Admin Panel</h2>
        <a href="manageEvents.php">Manage Events</a>
        <a href="addEvent.php">Add Event</a>
        <a href="viewBookings.php">View Bookings</a>
        <a href="logout.php" style="color: #dc3545;">Logout</a>
    </div>

    <!-- Main content -->
    <div class="main-content">
        <h2>Edit Event</h2>

        <form method="post" enctype="multipart/form-data">
            <label>Event Name:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($event['name']) ?>" required>

            <label>Date & Time:</label>
            <input type="datetime-local" name="date_time" value="<?= date('Y-m-d\TH:i', strtotime($event['date_time'])) ?>" required>

            <label>Location:</label>
            <input type="text" name="location" value="<?= htmlspecialchars($event['location']) ?>" required>

            <label>Ticket Price:</label>
            <input type="number" step="0.01" name="ticket_price" value="<?= $event['ticket_price'] ?>" required>

            <label>Maximum Tickets:</label>
            <input type="number" name="max_tickets" value="<?= $event['max_tickets'] ?>" required>

            <label>Event Image:</label>
            <div class="current-img">
                <img src="<?= $event['image'] ?>" alt="Current Image">
            </div>
            <input type="file" name="image">

            <label>Description:</label>
            <textarea name="description" rows="4"><?= htmlspecialchars($event['description']) ?></textarea>

            <input type="submit" value="Update Event">
            <p style="color:red;"><?= $error ?></p>
        </form>
    </div>
</div>

</body>
</html>
