<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

$reservation_success = false;
$customer_id = $_SESSION['user'];
$reservation_time = date('Y-m-d H:i:s');

if (isset($_POST['reserve'])) {
    if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            if (is_array($item) && isset($item['event_id']) && !empty($item['event_id'])) {
                $itemTotal = $item['price'] * $item['quantity'];

                $stmt = $conn->prepare("INSERT INTO bookings (customer_id, event_id, num_tickets, total_price, booking_date) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("iiids", $customer_id, $item['event_id'], $item['quantity'], $itemTotal, $reservation_time);
                $stmt->execute();
            }
        }
        unset($_SESSION['cart']);
        $reservation_success = true;
    }
}

$cart = isset($_SESSION['cart']) && is_array($_SESSION['cart']) ? $_SESSION['cart'] : [];
$totalQuantity = array_sum(array_column($cart, 'quantity'));
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
        }

        .logout-button {
            background-color: #dc3545;
            padding: 8px 16px;
            border-radius: 5px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .logout-button:hover {
            background-color: #c82333;
        }

        .header-bar {
            background: #333;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-left {
            font-weight: bold;
            font-size: 20px;
        }

        .header-right a {
            color: white;
            margin-left: 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .cart-button {
            background-color: #007bff;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .cart-button:hover {
            background-color: #0056b3;
        }

        .main-container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #f0f0f0;
            color: #333;
            font-weight: bold;
        }

        .total-line {
            text-align: left;
            margin-top: 15px;
            font-size: 18px;
            font-weight: bold;
        }

        .reserve-btn {
            display: block;
            margin: 30px auto 0;
            padding: 12px 40px;
            background: #28a745;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
        }

        .reserve-btn:hover {
            background: #218838;
        }

        .success-message {
            text-align: center;
            color: green;
            font-weight: bold;
            font-size: 20px;
            margin-top: 30px;
        }

        .footer-bar {
            background: #333;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }
    </style>
</head>

<body>

    <div class="header-bar">
        <div class="header-left">
            <a href="home.php" style="color:inherit; text-decoration:none;">Event Booking System</a>
        </div>
        <div class="header-right">
            <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="cart.php" class="cart-button">Cart<?= $totalQuantity > 0 ? " ($totalQuantity)" : "" ?></a>
            <a href="logoutCustomer.php" class="nav-button logout-button">Logout</a>
        </div>
    </div>

    <div class="main-container">
        <h2>Your Cart</h2>
        <p style="text-align:center;">Current Date: <?= date('l, F j, Y \a\t h:i:s A') ?></p>

        <table>
            <tr>
                <th>Event</th>
                <th>Date</th>
                <th>Quantity</th>
                <th>Price (SAR)</th>
                <th>Total (SAR)</th>
            </tr>
            <?php if (!empty($cart)): ?>
                <?php $grandTotal = 0; ?>
                <?php foreach ($cart as $item): ?>
                    <?php if (is_array($item)): ?>
                        <?php
                        $itemTotal = $item['price'] * $item['quantity'];
                        $grandTotal += $itemTotal;
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td><?= htmlspecialchars(date('F j, Y', strtotime($item['date']))) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= number_format($item['price'], 2) ?></td>
                            <td><?= number_format($itemTotal, 2) ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">Your cart is empty.</td>
                </tr>
            <?php endif; ?>
        </table>

        <?php if (!empty($cart)): ?>
            <div class="total-line">Total: <?= number_format($grandTotal, 2) ?> SAR</div>

            <form method="post">
                <button type="submit" name="reserve" class="reserve-btn">Reserve Tickets</button>
            </form>
        <?php endif; ?>

        <?php if ($reservation_success): ?>
            <p class="success-message">🎉 Tickets Reserved Successfully! 🎉</p>
        <?php endif; ?>
    </div>

    <div class="footer-bar">
        &copy; <?= date('Y') ?> Event Booking System
    </div>

</body>

</html>