<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit;
}

require 'config.php';

// Make sure event ID is passed
if (!isset($_GET['id'])) {
    header("Location: manageEvents.php");
    exit;
}

$event_id = $_GET['id'];

// Get event info
$event = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM events WHERE event_id = $event_id"));

// Count bookings for the event
$bookingResult = mysqli_query($conn, "SELECT COUNT(*) as total FROM bookings WHERE event_id = $event_id");
$bookingData = mysqli_fetch_assoc($bookingResult);
$bookingCount = $bookingData['total'];

// Handle deletion confirmation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_delete'])) {
    // Only delete if no bookings
    if ($bookingCount == 0) {
        mysqli_query($conn, "DELETE FROM events WHERE event_id = $event_id");
        header("Location: manageEvents.php");
        exit;
    }
}

// Handle cancel
if (isset($_POST['cancel'])) {
    header("Location: manageEvents.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Event</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dashboard {
            display: flex;
        }

        .side-menu {
            width: 220px;
            background-color: #1e1e1e;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }

        .side-menu a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .main-content {
            margin-left: 240px;
            padding: 40px;
            width: 100%;
        }

        .delete-box {
            background-color: #fff0f0;
            border: 1px solid #f5c6cb;
            padding: 20px;
            border-radius: 6px;
            max-width: 500px;
        }

        .delete-box h3 {
            color: #cc0000;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
            padding: 8px 16px;
            border: none;
            margin-right: 10px;
        }

        .btn-secondary {
            background-color: #ccc;
            padding: 8px 16px;
            border: none;
        }

        .btn-danger:disabled {
            background-color: #999;
            cursor: not-allowed;
        }

        p {
            margin: 8px 0;
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- Sidebar -->
    <div class="side-menu">
        <h2>Admin Panel</h2>
        <a href="manageEvents.php">Manage Events</a>
        <a href="addEvent.php">Add Event</a>
        <a href="viewBookings.php">View Bookings</a>
        <a href="logout.php" style="color: #dc3545;">Logout</a>
    </div>

    <!-- Main content -->
    <div class="main-content">
        <h2>Delete Event</h2>
        <div class="delete-box">
            <h3>Confirm Deletion</h3>
            <p>Are you sure you want to delete the following event?</p>
            <p><strong><?= htmlspecialchars($event['name']) ?></strong></p>
            <p><strong>Date:</strong> <?= $event['date_time'] ?></p>
            <p><strong>Location:</strong> <?= $event['location'] ?></p>
            <p><strong>Bookings:</strong> <?= $bookingCount ?>
                <?php if ($bookingCount > 0): ?>
                    (This event has bookings and cannot be deleted)
                <?php endif; ?>
            </p>

            <form method="post">
                <button type="submit" name="cancel" class="btn-secondary">Cancel</button>
                <button type="submit" name="confirm_delete" class="btn-danger" <?= $bookingCount > 0 ? 'disabled' : '' ?>>
                    Yes, Delete this Event
                </button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
