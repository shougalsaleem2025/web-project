<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

// Correct cart quantity
$cart_quantity = isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;

// Fetch events
$result = mysqli_query($conn, "SELECT * FROM events");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Home - Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
        }

        .header-bar {
            background: #333;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-left {
            font-weight: bold;
            font-size: 20px;
        }

        .header-right a {
            color: white;
            margin-left: 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .cart-button {
            background-color: #007bff;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .cart-button:hover {
            background-color: #0056b3;
        }

        .main-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .event-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
            margin-top: 30px;
        }

        @media (max-width: 992px) {
            .event-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .event-grid {
                grid-template-columns: 1fr;
            }
        }

        .event-card {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
            transition: box-shadow 0.3s ease;
            position: relative;
        }

        .event-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .event-card-content {
            padding: 15px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
        }

        .event-card h3 {
            margin: 10px 0;
        }

        .book-btn {
            background-color: #3366ff;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 15px;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            opacity: 0;
            margin-bottom: 20px;
            transition: opacity 0.4s ease;
            pointer-events: none;
        }

        .event-card:hover .book-btn {
            opacity: 1;
            pointer-events: auto;
        }

        .footer-bar {
            background: #333;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }

        .logout-button {
            background-color: #dc3545;
            padding: 8px 16px;
            border-radius: 5px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .logout-button:hover {
            background-color: #c82333;
        }
    </style>
</head>

<body>

    <div class="header-bar">
        <div class="header-left">Event Booking System</div>
        <div class="header-right">
            <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="cart.php" class="cart-button">Cart<?= $cart_quantity > 0 ? " ($cart_quantity)" : "" ?></a>
            <a href="logoutCustomer.php" class="nav-button logout-button">Logout</a>
        </div>
    </div>

    <div class="main-container">
        <h2>Available Events</h2>
        <div class="event-grid">
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="event-card">
                    <img src="<?= htmlspecialchars($row['image']) ?>" alt="Event Image">

                    <div class="event-card-content">
                        <h3><?= htmlspecialchars($row['name']) ?></h3>
                        <p><strong>Date:</strong> <?= date('F j, Y – h:i A', strtotime($row['date_time'])) ?></p>
                    </div>

                    <a href="event.php?id=<?= $row['event_id'] ?>">
                        <button class="book-btn">Book Now</button>
                    </a>
                </div>

            <?php endwhile; ?>
        </div>
    </div>

    <div class="footer-bar">
        &copy; <?= date('Y') ?> Event Booking System
    </div>

</body>

</html>