<?php
session_start();

// Redirect to login if admin is not logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit;
}

require 'config.php';

$error = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form values
    $name = $_POST["name"];
    $date_time = $_POST["date_time"];
    $location = $_POST["location"];
    $ticket_price = $_POST["ticket_price"];
    // Handle image upload
$image = "";
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $uploadDir = "uploads/";
    $imageName = basename($_FILES["image"]["name"]);
    $targetFile = $uploadDir . $imageName;

    // Move file to uploads/ folder
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
        $image = $targetFile;
    }
}

    $max_tickets = $_POST["max_tickets"];
    
    $description = $_POST["description"];

    // Validate all fields are filled
    if ($name && $date_time && $location && $ticket_price && $image && $max_tickets && $description) {
        // Prepare SQL insert statement
        $sql = "INSERT INTO events (name, date_time, location, ticket_price, image, max_tickets, description)
        VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssssis", $name, $date_time, $location, $ticket_price, $image, $max_tickets, $description);
        mysqli_stmt_execute($stmt);

        // Redirect back to event management page
        header("Location: manageEvents.php");
        exit;
    } else {
        $error = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Event</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dashboard {
            display: flex;
        }

        .side-menu {
            width: 220px;
            background-color: #1e1e1e;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }

        .side-menu h2 {
            font-size: 20px;
            margin-bottom: 30px;
        }

        .side-menu a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .side-menu a:hover {
            text-decoration: underline;
        }

        .main-content {
            margin-left: 240px;
            padding: 40px;
            width: 100%;
        }

        input, label {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            width: auto;
        }
        
    </style>
</head>
<body>

<div class="dashboard">
    <!-- Sidebar -->
    <div class="side-menu">
        <h2>Admin Panel</h2>
        <a href="manageEvents.php">Manage Events</a>
        <a href="addEvent.php">Add Event</a>
        <a href="viewBookings.php">View Bookings</a>
        <a href="logout.php" style="color: #dc3545;">Logout</a>
    </div>

    <!-- Main Content Area -->
    <div class="main-content">
        <h2>Add New Event</h2>

        <!-- Event form -->
<form method="post" enctype="multipart/form-data">
    <label>Event Name:</label>
    <input type="text" name="name" style="width: 300px;" required>

    <label>Event Date:</label>
    <input type="datetime-local" name="date_time" style="width: 300px;" required>

    <label>Location:</label>
    <input type="text" name="location" style="width: 300px;" required>

    <label>Ticket Price ($):</label>
    <input type="number" step="0.01" name="ticket_price" style="width: 300px;" required>

    <label>Maximum Tickets:</label>
    <input type="number" name="max_tickets" style="width: 300px;" required>

    <label>Event Image:</label>
    <input type="file" name="image" style="width: 300px;" required>

    <label>Description:</label>
    <textarea name="description" rows="4" cols="40" style="width: 300px;"></textarea>

    <br><br>
    <input type="submit" value="Add Event" style="background-color: green; color: white; padding: 8px 16px; border: none;">
    <p style="color:red;"><?= $error ?></p>
</form>

    </div>
</div>

</body>
</html>
