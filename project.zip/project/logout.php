<?php
session_start();              // Start the session
session_unset();              // Clear all session variables
session_destroy();            // Destroy the session completely
header("Location: admin.php"); // Redirect to login page
exit;
?>
