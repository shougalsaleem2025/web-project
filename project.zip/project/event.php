<?php
session_start();
require 'config.php';

if (!isset($_SESSION["username"])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Missing event ID.");
}

$eventId = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM events WHERE event_id = ?");
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();
$event = $result->fetch_assoc();

if (!$event) {
    die("Event not found.");
}

// Calculate available tickets
$bookedQuery = $conn->prepare("SELECT SUM(num_tickets) AS total_booked FROM bookings WHERE event_id = ?");
$bookedQuery->bind_param("i", $eventId);
$bookedQuery->execute();
$bookedResult = $bookedQuery->get_result()->fetch_assoc();
$booked = $bookedResult['total_booked'] ?? 0;
$available = $event['max_tickets'] - $booked;

$stmt->close();

$cart_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['quantity'])) {
    $new_quantity = intval($_POST['quantity']);
    $event_id = $event['event_id'];

    if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        foreach ($_SESSION['cart'] as $item) {
            if ($item['event_id'] != $event_id) {
                $_SESSION['cart'] = [];
                $cart_message = "⚠️ Your cart was cleared because you selected a different event.";
                break;
            }
        }
    }

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if (is_array($item) && isset($item['event_id']) && $item['event_id'] == $event_id) {
            $item['quantity'] += $new_quantity;
            $found = true;
            break;
        }
    }
    unset($item);

    if (!$found) {
        $_SESSION['cart'][] = [
            'event_id' => $event['event_id'],
            'name' => $event['name'],
            'date' => $event['date_time'],
            'price' => $event['ticket_price'],
            'image' => $event['image'],
            'quantity' => $new_quantity
        ];
    }

    $success_message = "✅ Added to cart successfully!";
}

$cart_quantity = isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;
?>

<!DOCTYPE html>
<html>

<head>
    <title>Book Tickets</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .header-bar {
            background: #333;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-button {
            background-color: #dc3545;
            padding: 8px 16px;
            border-radius: 5px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .logout-button:hover {
            background-color: #c82333;
        }

        .header-left {
            font-weight: bold;
            font-size: 18px;
        }

        .header-right a {
            color: white;
            margin-left: 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .main-container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .event-details {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
        }

        .event-image {
            flex: 1;
            min-width: 250px;
        }

        .event-image img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
        }

        .event-info {
            flex: 2;
            min-width: 250px;
        }

        .event-info p {
            margin: 8px 0;
            font-size: 16px;
            word-break: break-word;
            overflow-wrap: break-word;
        }

        .booking-section {
            margin-top: 30px;
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .booking-section input[type="number"] {
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 80px;
            font-size: 16px;
            text-align: center;
        }

        .booking-section input[type="submit"] {
            background-color: #3366ff;
            color: white;
            border: none;
            padding: 10px 30px;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
        }

        .booking-section input[type="submit"]:hover {
            background-color: #254eda;
        }

        .footer-bar {
            text-align: center;
            padding: 20px;
            margin-top: 40px;
            background: #333;
            color: white;
        }
    </style>
</head>

<body>

    <div class="header-bar">
        <div class="header-left">
            <a href="home.php" style="text-decoration: none; color: inherit;">Event Booking System</a>
        </div>
        <div class="header-right">
            <span class="welcome-text">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="cart.php" class="nav-button">Cart<?php if ($cart_quantity > 0)
                echo " ($cart_quantity)"; ?></a>
            <a href="logoutCustomer.php" class="nav-button logout-button">Logout</a>
        </div>
    </div>

    <div class="main-container">
        <div class="event-details">
            <div class="event-image">
                <img src="<?= htmlspecialchars($event['image']) ?>" alt="Event Image">
            </div>

            <div class="event-info">
                <h2><?= htmlspecialchars($event['name']) ?></h2>
                <p><strong>Date:</strong> <?= date('F j, Y', strtotime($event['date_time'])) ?></p>
                <p><strong>Time:</strong> <?= date('h:i A', strtotime($event['date_time'])) ?></p>
                <p><strong>Location:</strong> <?= htmlspecialchars($event['location']) ?></p>
                <p><strong>Price:</strong> <?= number_format($event['ticket_price'], 2) ?> SAR</p>
                <p><strong>Available Tickets:</strong> <?= $available ?></p>
                <p><strong>Description:</strong><br><?= nl2br(htmlspecialchars($event['description'])) ?></p>
            </div>
        </div>

        <div class="booking-section">
            <h3>Book Tickets</h3>
            <form method="POST">
                <input type="number" name="quantity" min="1" max="<?= $available ?>" required>
                <br>
                <input type="submit" value="Add to Cart">
            </form>

            <?php if (isset($success_message)): ?>
                <p style="color: green; font-weight: bold; margin-top: 20px;"><?= $success_message ?></p>
            <?php endif; ?>

            <?php if (!empty($cart_message)): ?>
                <p style="color: orange; font-weight: bold; margin-top: 15px;"><?= $cart_message ?></p>
            <?php endif; ?>
        </div>
    </div>

    <footer class="footer-bar">
        &copy; <?= date('Y') ?> Event Booking System
    </footer>

</body>

</html>